#include<stdio.h>
#define SIZE 3

struct Contact
{
    char name[20];
    unsigned long long int phone_num;
    char email[100];
};

int compare_two_name(char first[20],char second[20]);
int char_count(char name[20]);

int main()
{
    struct Contact contact[SIZE];
    char s_name[20];
    int result;
    int count=0;

    FILE *fptr=fopen("contact.txt","r");

    if(fptr!=NULL)
    {
        for(int i=0;i<SIZE;i++)
        {
            fscanf(fptr,"%s%llu%s",&contact[i].name,&contact[i].phone_num,&contact[i].email);
        }
    }
    else
    {
        printf("File opening error!\n");
    }

    printf("Enter the name for search: ");
    scanf(" %[^\n]",&s_name);

    for(int i=0;i<SIZE;i++)
    {
        result=compare_two_name(s_name,contact[i].name);

        if(result==1)
        {
            printf("\n*****Searching Result*****\n");
            printf("Name: %s\n",contact[i].name);
            printf("Phone number: %llu\n",contact[i].phone_num);
            printf("Email: %s\n",contact[i].email);
        }
        else
        {
            count++;
        }
    }
    if(count==SIZE)
    {
        printf("Not found!\n");
    }

    return 0;
}

int compare_two_name(char first[20],char second[20])
{
    int f_count=char_count(first);
    int s_count=char_count(second);
    int same_count=0;

    if(f_count == s_count)
    {
        for(int i=0;i<f_count;i++)
        {
            if(first[i]==second[i])
            {
                same_count++;
            }
        }
        if(f_count==same_count)
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }
}

int char_count(char name[20])
{
    int counter=0;
    while(name[counter]!='\0')
    {
        counter++;
    }
    return counter;
}
