#include<stdio.h>
#define BOOK_SIZE 100

struct Book
{
    char book_title[100];
    char author[50];
    int public_year;
};

int main()
{
    struct Book book[BOOK_SIZE];
    struct Book *ptr;
    ptr=book;
    int num;

    printf("Enter the number of book: ");
    scanf("%d",&num);

    for(int i=0;i<num;i++)
    {
        printf("\nEnter the book title: ");
        scanf(" %[^\n]",&book[i].book_title);
        printf("Enter the author name: ");
        scanf(" %[^\n]",&book[i].author);
        printf("Enter the publication year: ");
        scanf("%d",&book[i].public_year);
    }

    int b=0;
    for(int j=1;j<num;j++)
    {
        if((ptr+b)->public_year > (ptr+j)->public_year)
        {
            b=j;
        }
    }

    printf("\n*****Book with the earliest publication year*****\n");
    printf("\nBook title: %s\n",(ptr+b)->book_title);
    printf("Author name: %s\n",(ptr+b)->author);
    printf("Publication year: %d\n",(ptr+b)->public_year);

    return 0;
}
