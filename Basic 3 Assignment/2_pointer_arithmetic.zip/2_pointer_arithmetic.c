#include<stdio.h>
#define SIZE 10

int main()
{
    int arr[SIZE]={10,20,30,40,50,60,70,80,90,100};
    int *ptr;
    ptr=arr;
    int sum=0;

    for(int i=0;i<SIZE;i++)
    {
        sum += *(ptr+i);
    }
    float average=sum/SIZE;

    printf("Sum of array elements: %d\n",sum);
    printf("Average of array elements: %.2f\n",average);

    return 0;
}
