#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *dyn_arr=NULL;
    int size;
    int sum=0;

    printf("Enter the size of array: ");
    scanf("%d",&size);

    dyn_arr=malloc(size*sizeof(int));

    if(dyn_arr!=NULL)
    {
        for(int i=0; i<size; i++)
        {
            printf("Enter the elements of array[%d]: ",i);
            scanf("%d",&dyn_arr[i]);
        }
        for(int j=0; j<size; j++)
        {
            sum+=dyn_arr[j];
        }
    }
    else
    {
        printf("Memory allocation failed!\n");
    }

    printf("\nSum of the array elements: %d\n",sum);

    free(dyn_arr);
    return 0;
}
