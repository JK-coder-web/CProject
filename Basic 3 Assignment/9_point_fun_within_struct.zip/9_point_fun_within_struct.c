#include<stdio.h>
#include<stdlib.h>

struct Operation
{
    int (*fptr)(int,int);
};

int addition(int a,int b);
int subtraction(int a,int b);
int multi(int a,int b);
int division(int a,int b);

int main()
{
    struct Operation op;
    int type;
    int result;

    printf("Enter 1 for addition:\nEnter 2 for subtraction:\nEnter 3 for multiplication:\nEnter 4 for division: ");
    scanf("%d",&type);

    if(type==1)
    {
        op.fptr=addition;
        result=op.fptr(15,12);
        printf("Addition is %d\n",result);
    }
    else if(type==2)
    {
        op.fptr=subtraction;
        result=op.fptr(15,12);
        printf("Subtraction is %d\n",result);
    }
    else if(type==3)
    {
        op.fptr=multi;
        result=op.fptr(15,12);
        printf("Multiplication is %d\n",result);
    }
    else if(type==4)
    {
        op.fptr=division;
        result=op.fptr(15,12);
        printf("Division is %d\n",result);
    }
    else
    {
        printf("Please enter (1,2,3,4): Try again!\n");
    }
    return 0;
}

int addition(int a,int b)
{
    return a+b;
}
int subtraction(int a,int b)
{
    return a-b;
}
int multi(int a,int b)
{
    return a*b;
}
int division(int a,int b)
{
    if(b==0)
    {
        printf("In Division, divisor is not zero, Invalid input!\n");
        exit(1);
    }
    return a/b;
}
