#include<stdio.h>
#include<string.h>

struct Person
{
    char name[20];
    int age;
    char address[100];
};

int main()
{
    struct Person person;

    strcpy(person.name,"John Wish");
    person.age=36;
    strcpy(person.address,"New York, American");

    printf("Name : %s\n",person.name);
    printf("Age : %d\n",person.age);
    printf("Address : %s\n",person.address);

    return 0;
}
