#include<stdio.h>
#include<stdlib.h>

struct Operation
{
    int (*fptr)(int,int);
};

int addition(int a,int b);
int subtraction(int a,int b);
int multi(int a,int b);
int division(int a,int b);

int main()
{
    struct Operation op;
    int result;

    op.fptr=addition;
    result=op.fptr(10,5);
    printf("Addition is %d\n",result);

    op.fptr=subtraction;
    result=op.fptr(10,5);
    printf("Subtraction is %d\n",result);

    op.fptr=multi;
    result=op.fptr(10,5);
    printf("Multiplication is %d\n",result);

    op.fptr=division;
    result=op.fptr(10,5);
    printf("Division is %d\n",result);

    return 0;
}

int addition(int a,int b)
{
    return a+b;
}
int subtraction(int a,int b)
{
    return a-b;
}
int multi(int a,int b)
{
    return a*b;
}
int division(int a,int b)
{
    if(b==0)
    {
        printf("In Division, divisor is not zero, Invalid input!\n");
        exit(1);
    }
    return a/b;
}
