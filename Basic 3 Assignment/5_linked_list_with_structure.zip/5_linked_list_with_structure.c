#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define STUDENTS_SIZE 100

struct Student
{
    char name[20];
    int roll;
    float marks;
};

struct Node
{
    struct Student student;
    struct Node* next;
};

void add_details(struct Node** head,struct Student details)
{
    struct Node* newNode=(struct Node*)malloc(sizeof(struct Node));
    struct Node* temp=*head;
    newNode->student=details;
    newNode->next=NULL;

    if(*head==NULL)
    {
        *head=newNode;
        return;
    }

    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
}

void display(struct Node* head)
{
    struct Node* temp=head;

    if(temp==NULL)
    {
        printf("Empty Data!\n");
        return;
    }

    while(temp!=NULL)
    {
        printf("\nName: %s\n",temp->student.name);
        printf("Roll: %d\n",temp->student.roll);
        printf("Marks: %.2f\n",temp->student.marks);
        temp=temp->next;
    }
}

int main()
{
    struct Node* head=NULL;
    struct Student stu[STUDENTS_SIZE];
    int num;

    printf("Enter the number of students: ");
    scanf("%d",&num);

    for(int i=0;i<num;i++)
    {
        printf("\nEnter the student's name: ");
        scanf(" %[^\n]",&stu[i].name);
        printf("Enter the roll number: ");
        scanf("%d",&stu[i].roll);
        printf("Enter marks: ");
        scanf("%f",&stu[i].marks);
    }

    for(int j=0;j<num;j++)
    {
        add_details(&head,stu[j]);
    }

    display(head);

    return 0;
}
