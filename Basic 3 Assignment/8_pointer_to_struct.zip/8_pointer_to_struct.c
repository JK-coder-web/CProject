#include<stdio.h>
#define SIZE 12

struct Date
{
    int day;
    int month;
    int year;
};

int check_leap(int yr);
int get_days_in_month(int month,int year);

int main()
{
    struct Date date1,date2;
    struct Date *ptr1;
    struct Date *ptr2;
    ptr1=&date1;
    ptr2=&date2;
    int days=0;

    printf("Enter date 1 (days,month,year): ");
    scanf("%d %d %d",&date1.day,&date1.month,&date1.year);

    printf("Enter date 2 (days,month,year): ");
    scanf("%d %d %d",&date2.day,&date2.month,&date2.year);

    for(int month=ptr1->month;month<=SIZE;month++)
    {
        int d=get_days_in_month(month,ptr1->year);
        days+=(d-(ptr1->day));
        ptr1->day=0;
    }

    for(int month=1;month<=(ptr2->month)-1;month++)
    {
        int d=get_days_in_month(month,ptr2->year);
        days+=d;
    }
    days+=ptr2->day;

    for(int i=(ptr1->year)+1;i<ptr2->year;i++)
    {
        int leap=check_leap(i);
        if(leap==1)
        {
            days+=366;
        }
        else
        {
            days+=365;
        }
    }

    printf("Days between two dates: %d\n",days);
    return 0;
}

int check_leap(int yr)
{
    if((yr%4==0 && yr%100!=0) || (yr%400==0))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int get_days_in_month(int month,int year)
{
    int days_per_month[SIZE]={31,28,31,30,31,30,31,31,30,31,30,31};
    int leap=check_leap(year);

    if(month==2 && leap==1)
    {
        return 29;
    }
    else
    {
        return days_per_month[month-1];
    }
}
