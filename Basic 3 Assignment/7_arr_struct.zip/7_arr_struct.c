#include<stdio.h>
#define SIZE 100

struct Employee
{
    char name[20];
    int employ_id;
    double salary;
};

int main()
{
    struct Employee em[SIZE];
    int em_num;

    printf("Enter the number of employee: ");
    scanf("%d",&em_num);

    for(int i=0;i<em_num;i++)
    {
        printf("\nEnter details for emoployee %d:\n",i+1);
        printf("Enter the employee name: ");
        scanf(" %[^\n]",&em[i].name);
        printf("Enter the employee id: ");
        scanf("%d",&em[i].employ_id);
        printf("Enter the employee salary: ");
        scanf("%lf",&em[i].salary);
    }

    int index=0;

    for(int j=1;j<em_num;j++)
    {
        if(em[index].salary<em[j].salary)
        {
            index=j;
        }
    }

    printf("\n*****Employee with the highest salary*****\n");
    printf("\nEmployee name: %s\n",em[index].name);
    printf("Employee id: %d\n",em[index].employ_id);
    printf("Employee salary: %.2lf\n",em[index].salary);

    return 0;
}
