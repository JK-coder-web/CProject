#include<stdio.h>
int main()
{
    int space=0;
    int word=0;
    int line=0;
    FILE *fptr;
    fptr=fopen("source.txt","r");
    if(fptr==NULL)
    {
        printf("We cannot read data.\n");
    }
    else
    {
        while(!(feof(fptr)))
        {
            char c=fgetc(fptr);
            if(c==' ')
            {
                space++;
                word++;
            }
            else if(c=='\n')
            {
                word++;
                line++;
            }
        }
        printf("Space = %d\n",space);
        printf("Word = %d\n",word);
        printf("Line = %d\n",line);
    }
    fclose(fptr);
    FILE *fptr2;
    fptr2=fopen("result.txt","w");
    if(fptr2==NULL)
    {
        printf("We cannot write file.\n");
    }
    else
    {
        fprintf(fptr2,"Space = %d\n",space);
        fprintf(fptr2,"Word = %d\n",word);
        fprintf(fptr2,"Line = %d\n",line);
    }
    fclose(fptr2);
    return 0;
}
