#include<stdio.h>
int main()
{
    int arr_data[100];
    int num;
    int sum=0;
    printf("Please enter the size of the array(1-100): ");
    scanf("%d",&num);

    for(int i=0;i<num;i++)
    {
        printf("Enter element %d : ",i);
        scanf("%d",&arr_data[i]);
        sum+=arr_data[i];
    }

    printf("\nBefore sorting =");
    for(int a=0;a<num;a++)
    {
        printf(" %d",arr_data[a]);
    }
    printf("\n");

    for(int j=0;j<num;j++)
    {
        for(int z=j+1;z<num;z++)
        {
            if(arr_data[j]>arr_data[z])
            {
                int temp=arr_data[j];
                arr_data[j]=arr_data[z];
                arr_data[z]=temp;
            }
        }
    }

    printf("\nSum of array elements = %d\n",sum);
    printf("Largest element in the array = %d\n",arr_data[num-1]);

    printf("After sorting ascending order =");
    for(int a=0;a<num;a++)
    {
        printf(" %d",arr_data[a]);
    }
    printf("\n");
    return 0;
}
