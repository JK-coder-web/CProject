#include<stdio.h>
#define SIZE 6

struct Student
{
    char name[20];
    int roll;
    float marks[SIZE];
};

struct Student input_Student_data();
double average_marks(float marks[]);
void display(struct Student stu,double average);

int main()
{
    struct Student data;
    data=input_Student_data();

    double average=average_marks(data.marks);
    display(data,average);

    return 0;
}

struct Student input_Student_data()
{
    struct Student stu;
    printf("Enter the name of student: ");
    scanf(" %[^\n]",&stu.name);
    printf("Enter roll number: ");
    scanf("%d",&stu.roll);

    for(int i=0;i<SIZE;i++)
    {
        printf("Enter marks for subject %d : ",i+1);
        scanf("%f",&stu.marks[i]);
    }

    return stu;
}

double average_marks(float marks[])
{
    double total=0;
    for(int j=0;j<SIZE;j++)
    {
        total+=marks[j];
    }
    total/=SIZE;

    return total;
}

void display(struct Student stu,double average)
{
    printf("\nStudent's name = %s\n",stu.name);
    printf("Roll number = %d\n",stu.roll);

    for(int a=0;a<SIZE;a++)
    {
        printf("Marks of subject %d = %.2f\n",a+1,stu.marks[a]);
    }
    printf("Average marks = %.2lf\n",average);
}

