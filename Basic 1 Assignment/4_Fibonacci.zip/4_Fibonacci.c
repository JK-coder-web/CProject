#include<stdio.h>
int main()
{
    int limit=0;
    unsigned long next=0;
    unsigned long last=1;

    printf("Enter the limit: ");
    scanf("%d",&limit);

    while(limit!=0)
    {
        printf("%lu ",last);

        unsigned long sum=next+last;
        next=last;
        last=sum;

        limit--;
    }
    printf("\n");

    return 0;
}
