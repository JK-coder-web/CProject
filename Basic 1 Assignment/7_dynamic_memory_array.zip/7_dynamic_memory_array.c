#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *dyn_arr=NULL;
    int i=0;
    int size=5;

    dyn_arr=calloc(size,sizeof(int));
    if(dyn_arr==NULL)
    {
        printf("\nMemory not allocated!\n");
    }
    else{
            printf("\nMemory successfully allocated!\n");
        for(i=0;i<size;i++)
        {
            dyn_arr[i]=i*2;
        }
        for(i=0;i<size;i++)
        {
            printf("Dynamic Array[%d] = %d\n",i,dyn_arr[i]);
        }
    }

    int new_size=10;
    dyn_arr=realloc(dyn_arr,new_size*sizeof(int));
    if(dyn_arr==NULL)
    {
        printf("\nMemory not reallocated!\n");
    }
    else{
        printf("\nMemory successfully reallocated!\n");
        for(i=size;i<new_size;i++)
        {
            dyn_arr[i]=i*2;
        }
        for(i=0;i<new_size;i++)
        {
            printf("Dynamic Array[%d] = %d\n",i,dyn_arr[i]);
        }
    }
    free(dyn_arr);
    printf("\nMemory successfully deallocated!\n");
    return 0;
}
