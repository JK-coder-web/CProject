#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node* next;
};

void insertNode(struct Node** head, int value)
{
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    struct Node* temp = *head;
    newNode->data = value;
    newNode->next = NULL;

    if (*head == NULL)
    {
        *head = newNode;
        return;
    }

    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = newNode;
}

void deleteNode(struct Node** head_ref,int num)
{
    struct Node* prev=NULL;

    struct Node* temp=*head_ref;
    if(temp!=NULL && temp->data==num)
    {
        *head_ref=temp->next;
        free(temp);
        return;
    }
    else
    {
        while(temp!=NULL && temp->data != num)
        {
            prev=temp;
            temp=temp->next;
        }
        if(temp==NULL)
            return;
        prev->next=temp->next;
        free(temp);
    }
    printf("Linked list after deletion(%d)\n",num);
}

void displayLinkedList(struct Node* head)
{
    struct Node* temp = head;

    if (temp == NULL)
    {
        printf("Linked list is empty.\n");
        return;
    }

    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }

    printf("\n");
}

int main()
{
    struct Node* head = NULL;

    // Insertion
    insertNode(&head, 10);
    insertNode(&head, 20);
    insertNode(&head, 30);
    insertNode(&head, 40);

    printf("Linked list after insertion:\n");
    displayLinkedList(head);
    printf("\n");

    // Deletion
    deleteNode(&head,30);

    displayLinkedList(head);

    return 0;
}
