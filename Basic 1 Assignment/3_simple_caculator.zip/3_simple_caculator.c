#include<stdio.h>
int main()
{
    float num1=0;
    float num2=0;
    char op;

    printf("Enter an operator(+,-,*,/): ");
    scanf("%c",&op);
    printf("Enter a first number: ");
    scanf("%f",&num1);
    printf("Enter a second number: ");
    scanf("%f",&num2);

    switch(op)
    {
        case '+':
            printf("Answer = %.2f\n",num1+num2);
            break;
        case '-':
            printf("Answer = %.2f\n",num1-num2);
            break;
        case '*':
            printf("Answer = %.2f\n",num1*num2);
            break;
        case '/':
            printf("Answer = %.2f\n",num1/num2);
            break;
        default:
            printf("Invalid operator! Try again!\n");
    }

    return 0;
}
