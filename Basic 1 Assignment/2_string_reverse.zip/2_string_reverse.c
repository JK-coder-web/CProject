#include<stdio.h>
int main()
{
    int i=0;
    int a=0;
    char string1[100];
    char string2[100];

    for(int i=0;i<100;i++)
    {
        string1[i]='\0';
        string2[i]='\0';
    }

    printf("Enter a string = ");
    scanf(" %[^\n]",&string1);

    while(string1[i]!='\0')
    {
        i++;
    }
    for(int j=i-1;j>=0;j--)
    {
        string2[a]=string1[j];
        a++;
    }

    printf("\nReverse string = %s\n",string2);
    return 0;
}
